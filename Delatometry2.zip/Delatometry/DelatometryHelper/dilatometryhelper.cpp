#include "dilatometryhelper.h"
#include "ui_dilatometryhelper.h"

#include <QFileDialog>
#include <Qfile>
#include <QTextStream>
#include <QIODevice>
#include <QMessageBox>
#include <QLocale>

DilatometryHelper::DilatometryHelper(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::DilatometryHelper)
{
    ui->setupUi(this);
}

DilatometryHelper::~DilatometryHelper()
{
    delete ui;
}

void DilatometryHelper::processFiles()
{
    QFile file(ui->leTempr->text());
    file.open(QIODevice::ReadOnly);
    if (!file.isOpen())
    {
        QMessageBox::information(this, "Помилка", "Неможливо відкрити файл з температурою!\n"
                                 "Перевірьте чи правильно введене ім'я файлу.");
    }
    QTextStream strim(&file);
	QString temper;
    temper.append(strim.readAll());
	QString temp;
	QString num;
	std::vector <double> data;
	int i = 0;

	foreach (QChar c, temper)
    {
        if (c == '<')
        {
			temp.clear();
            temp.append(c);
            continue;
		}else if (c == '>')
        {
            temp.append(c);
			if (temp == "</TD>")
			{
				++i;
				QLocale german(QLocale::German);
				double t = german.toDouble(num);
				if (i%2 == 0)
				{

					data.push_back(t);
				}
				num.clear();
			}
			continue;
			//break;
        }
		else
		{
			if (temp == "<TD>")
			{
				num.append(c);
			}
			else
			{
				temp.append(c);
			}
		}

    }
}

void DilatometryHelper::on_pbOpenTempr_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open file"), "./", "Text File (*.txt)");
    ui->leTempr->setText(fileName);
}

void DilatometryHelper::on_pbOpenDilat_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open file"), "./", "Text File (*.txt)");
    ui->leDilat->setText(fileName);
}

void DilatometryHelper::on_pbStartProcess_clicked()
{
    processFiles();
}
